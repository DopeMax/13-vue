<template>
<div>
  <h3>SearchContainer</h3>
</div>
</template>
<script>
 export default {
   data: ()=>({
   }),
   components: {
   }
 }
</script>
<style lang="scss" scoped>
 
</style>