<template>
<div>
{{id}}
</div>
</template>
<script>
 export default {
   created(){
     this.id=this.$route.params.id;
     
   },
   data: ()=>({
     id: ""
   }),
   components: {
   }
 }
</script>
<style lang="scss" scoped>
 
</style>