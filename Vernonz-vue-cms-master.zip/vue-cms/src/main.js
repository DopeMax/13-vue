// 入口文件
import Vue from "vue";
import { Header,Swipe, SwipeItem } from 'mint-ui';
Vue.component(Header.name, Header);
import './lib/mui/css/mui.min.css';
import './lib/mui/css/icons-extra.css';

import VueResource from 'vue-resource' 

Vue.use(VueResource)

//导入路由包
import VueRouter from 'vue-router'
//安装路由
Vue.use(VueRouter)
//安装轮播图组件
Vue.component(Swipe.name, Swipe);
Vue.component(SwipeItem.name, SwipeItem);
import moment from "moment";
Vue.filter('dataFormat',(dataStr,pattern="YYYY-MM-DD HH:mm:ss")=>{
    return moment(dataStr).format(pattern)
})
//导入自己的router.js路由模块
import router from "./router";
import app from "./App.vue";
import axios from 'axios'

    var vm=new Vue({
      el:'#app',
      render:c=>c(app),
      router //挂载路由对象到VM实例上
    })
