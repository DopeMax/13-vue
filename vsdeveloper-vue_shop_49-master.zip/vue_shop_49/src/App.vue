<template>
  <div id="app">
    <!-- 在 app 根组件中，只放了一个路由的占位符 -->
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
</style>
