<template>
  <div>
    <h4>Search</h4>
  </div>
</template>


<script>
export default {
  
}
</script>

<style lang="css" scoped>

</style>
