<template>
  <div>

    <!-- 轮播图组件 -->
    <myswipe :imgList="list"></myswipe>

    <!-- 九宫格布局区域 -->
    <ul class="mui-table-view mui-grid-view mui-grid-9">
      <li class="mui-table-view-cell mui-media mui-col-xs-4 mui-col-sm-3">
        <router-link to="/home/newslist">
          <span>
            <img src="../../images/menu3.png" alt="">
          </span>
          <div class="mui-media-body">新闻资讯</div>
        </router-link>
      </li>
      <li class="mui-table-view-cell mui-media mui-col-xs-4 mui-col-sm-3">
        <router-link to="/home/photolist">
          <span>
            <img src="../../images/menu4.png" alt="">
          </span>
          <div class="mui-media-body">图片分享</div>
        </router-link>
      </li>
      <li class="mui-table-view-cell mui-media mui-col-xs-4 mui-col-sm-3">
        <router-link to="/home/goodslist">
          <span>
            <img src="../../images/menu5.png" alt="">
          </span>
          <div class="mui-media-body">商品购买</div>
        </router-link>
      </li>
      <li class="mui-table-view-cell mui-media mui-col-xs-4 mui-col-sm-3">
        <a href="#">
          <span>
            <img src="../../images/menu6.png" alt="">
          </span>
          <div class="mui-media-body">留言反馈</div>
        </a>
      </li>
      <li class="mui-table-view-cell mui-media mui-col-xs-4 mui-col-sm-3">
        <a href="#">
          <span>
            <img src="../../images/menu9.png" alt="">
          </span>
          <div class="mui-media-body">视频专区</div>
        </a>
      </li>
      <li class="mui-table-view-cell mui-media mui-col-xs-4 mui-col-sm-3">
        <a href="#">
          <span>
            <img src="../../images/menu10.png" alt="">
          </span>
          <div class="mui-media-body">联系我们</div>
        </a>
      </li>
    </ul>

  </div>
</template>


<script>
// 导入全局配置对象
import config from '../../js/globalConfig.js'
// 导入轮播图子组件
import myswipe from '../subcom/myswipe.vue'

// 当前组件的实例
export default {
  data() {
    return {
      baseUrl: config.baseUrl, // 将数据API地址，保存到 data 上
      list: []
    }
  },
  created() {
    // 组件刚一创建出来，立即调用获取数据的方法
    this.getLunboList();
  },
  methods: { // 方法
    getLunboList() { // 获取轮播图的方法
      /* this.$http.get(config.baseUrl + '/api/getlunbo').then(res => {
        var result = res.body;
        if (result.status === 0) {
          // 将轮播图数据，保存到 list 中
          this.list = result.message;
        } else {
          console.log('获取数据失败!');
        }
      }); */

      // 注意：由于我们已经配置了数据请求的根路径，所以 这里的URL地址，前面不能带 / 
      this.$http.get('api/getlunbo').then(res => {
        var result = res.body;
        if (result.status === 0) {
          // 将轮播图数据，保存到 list 中
          result.message.forEach(item => {
            item.img = this.baseUrl + item.img;
          });
          this.list = result.message;
        } else {
          console.log('获取数据失败!');
        }
      });
    }
  },
  components: { myswipe }
}
</script>

<style lang="scss" scoped>
.mui-table-view-cell {
  img {
    width: 60px;
  }
}

.mui-grid-view.mui-grid-9 {
  background-color: #fff;
  border: 0;
}

.mui-grid-view.mui-grid-9 .mui-table-view-cell {
  border: 0;
}
</style>
