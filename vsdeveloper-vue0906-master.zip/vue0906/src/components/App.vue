<template>
  <div class="app">
    <!-- 这是 Header 区域 -->
    <!-- Mint-UI 是组件 -->
    <mt-header fixed title="黑马程序员·sh10期Vue项目">
      <a slot="left" @click.prevent="goback" v-if="isshowBack">
        <mt-button icon="back">返回</mt-button>
      </a>
    </mt-header>

    <!-- 容器组件 -->
    <router-view></router-view>

    <!-- 这是 底部 TabBar区域 -->
    <!-- 大家可以把 MUI 想象成 是移动端的 bootstrap -->
    <!-- MUI 只是普通的 HTML 代码片段。只不过有一些专门的样式，能够美化这些标签而已 -->
    <!-- 这是 MUI 中的 Tabbar -->
    <nav class="mui-bar mui-bar-tab">
      <router-link class="mui-tab-item1" to="/home">
        <span class="mui-icon mui-icon-home"></span>
        <span class="mui-tab-label">首页</span>
      </router-link>
      <router-link class="mui-tab-item1" to="/member">
        <span class="mui-icon mui-icon-contact">
        </span>
        <span class="mui-tab-label">会员</span>
      </router-link>
      <router-link class="mui-tab-item1" to="/shopcar">
        <span class="mui-icon mui-icon-extra mui-icon-extra-cart">
          <span class="mui-badge">{{count}}</span>
        </span>
        <span class="mui-tab-label">购物车</span>
      </router-link>
      <router-link class="mui-tab-item1" to="/search">
        <span class="mui-icon mui-icon-search"></span>
        <span class="mui-tab-label">搜索</span>
      </router-link>
    </nav>
  </div>
</template>

<script>
export default {
  data() {
    return {
      isshowBack: false
    }
  },
  created() {
    if (this.$route.path === '/home') {
      this.isshowBack = false;
    } else {
      this.isshowBack = true;
    }
  },
  methods: {
    goback() { // 点击后退
      this.$router.go(-1);
    }
  },
  computed: {
    'count': function() {
      // 购物车中所有商品的总数量，应该从 store 中的 car 身上获取
      var c = 0;
      this.$store.state.car.forEach(item => {
        c += item.count;
      });
      return c;
    }
  },
  watch: {
    '$route': function(newVal) {
      // console.log(newVal);
      // 如果 路径等于 /home，则隐藏 后退按钮
      if (newVal.path === '/home') {
        this.isshowBack = false;
      } else {
        this.isshowBack = true;
      }
    }
  }
}
</script>

<style scoped>
.app {
  padding-top: 40px;
  padding-bottom: 50px;
}

.router-link-active {
  /* color: #007aff; */
}

.mui-bar-tab .mui-tab-item1.mui-active {
  color: #007aff;
}

.mui-bar-tab .mui-tab-item1 {
  display: table-cell;
  overflow: hidden;
  width: 1%;
  height: 50px;
  text-align: center;
  vertical-align: middle;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: #929292;
}

.mui-bar-tab .mui-tab-item1 .mui-icon {
  top: 3px;
  width: 24px;
  height: 24px;
  padding-top: 0;
  padding-bottom: 0;
}

.mui-bar-tab .mui-tab-item1 .mui-icon~.mui-tab-label {
  font-size: 11px;
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
}
</style>