<template>
  <div>

    <ul class="mui-table-view">
      <li class="mui-table-view-cell mui-media" v-for="item in list" :key="item.id">
        <!-- 如果在 router-link 的 to 属性中，使用表达式拼接路由地址，那么，to 属性必须使用 v-bind: 形式进行数据绑定 -->
        <router-link :to="'/home/newsinfo/' + item.id">
          <img class="mui-media-object mui-pull-left" :src="item.img_url">
          <div class="mui-media-body">
            <h1>{{item.title}}</h1>
            <p class='mui-ellipsis'>
              <span>发表时间：{{item.add_time | dateFormat}}</span>
              <span>点击：{{item.click}}次</span>
            </p>
          </div>
        </router-link>
      </li>
    </ul>

  </div>
</template>

<script>
import { Toast } from 'mint-ui';

// 导出当前组件的实例对象
export default {
  data() {
    return {
      list: [] // 存放 新闻列表
    }
  },
  created() {
    this.getNewsList();
  },
  methods: { // 业务逻辑都写在这里
    getNewsList() { // 获取新闻列表
      this.$http.get('api/getnewslist').then(res => {
        const result = res.body;
        if (result.status === 0) {
          // 把数据保存到 data 中的 list 上
          this.list = result.message;
        } else {
          Toast('新闻列表获取失败！');
        }
      });
    }
  }
}
</script>

<style lang="scss" scoped>
h1 {
  font-size: 14px;
}

.mui-ellipsis {
  font-size: 10px;
  color: #26A2FF;
  display: flex;
  justify-content: space-between;
}
</style>
