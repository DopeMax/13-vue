<template>
  <div style="background-color:#eee;">

    <!-- 图片分类滑动区域 -->
    <div id="slider" class="mui-slider">
      <div id="sliderSegmentedControl" class="mui-scroll-wrapper mui-slider-indicator mui-segmented-control mui-segmented-control-inverted">
        <div class="mui-scroll">

          <a :class="['mui-control-item', item.id==0?'mui-active':'']" v-for="item in categoryList" :key="item.id" @click="reloadImgList(item.id)">
            {{item.title}}
          </a>

        </div>
      </div>

    </div>

    <!-- 图片列表区域 -->
    <ul>
      <li v-for="item in photoList" :key="item.id" @click="goPhotoInfo(item.id)">
        <img v-lazy="imgBaseUrl + item.img_url">
        <div class="info">
          <h4>{{item.title}}</h4>
          {{item.zhaiyao}}
        </div>
      </li>
    </ul>

  </div>
</template>

<script>
// 1. 导入 mui 的JS脚本
import mui from '../../lib/mui/js/mui.min.js'
// 导入全局配置文件
import config from '../../js/globalConfig.js'


export default {
  data() {
    return {
      categoryId: 0, // 默认要展示所有的图片
      categoryList: [], // 所有图片分类数组
      photoList: [], // 所有的图片列表
      imgBaseUrl: config.imgBaseURL // 图片服务器地址
    }
  },
  created() {
    this.getPhotoCategory();
    this.getPhotoList();
  },
  mounted() { // 当组件挂载到页面中之后，才能初始化 滑动插件
    mui('.mui-scroll-wrapper').scroll({
      deceleration: 0.0005 //flick 减速系数，系数越大，滚动速度越慢，滚动距离越小，默认值0.0006
    });
  },
  methods: {
    getPhotoCategory() { // 获取图片分类
      this.$http.get('api/getimgcategory').then(res => {
        if (res.body.status === 0) {
          // 自己手动把全部，拼接到 数组中
          res.body.message.unshift({ id: 0, title: '全部' });
          this.categoryList = res.body.message;
        } else {
          console.log('获取分类数据失败！');
        }
      });
    },
    getPhotoList() { // 获取所有的图片列表
      this.$http.get('api/getimages/' + this.categoryId).then(res => {
        var result = res.body;
        if (result.status === 0) {
          this.photoList = result.message;
        } else {
          console.log('获取图片列表失败！');
        }
      });
    },
    reloadImgList(id) { // 根据点击的图片分类，获取对应的图片列表
      this.categoryId = id;
      this.getPhotoList();
    },
    goPhotoInfo(id) { // 通过点击图片跳转到图片详情页面
      // this.$route用来获取 URL 中的 参数的和 相关URL地址的
      // this.$route
      // this.$router 是用来实现编程式导航的（用JS代码的方式代替 router-link，实现路由跳转）
      this.$router.push('/home/photoinfo/' + id);
    }
  }
}
</script>

<style lang="scss" scoped>
* {
  touch-action: none;
}

// 这是懒加载的样式
img[lazy=loading] {
  width: 40px;
  height: 300px;
  display: block;
  margin: 0 auto;
}

ul {
  list-style: none;
  margin: 0;
  padding: 10px;
  li {
    margin: 10px 0;
    box-shadow: 0 0 15px #999;
    position: relative;
    img {
      width: 100%;
      display: block;
    }
    .info {
      position: absolute;
      bottom: 0;
      color: #fff;
      font-size: 12px;
      background-color: rgba(0, 0, 0, 0.4);
      max-height: 84px;
      h4 {
        font-size: 13px;
      }
    }
  }
}
</style>
