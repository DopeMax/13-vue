export default {
  baseUrl: 'http://127.0.0.1:8899', // 基本的数据服务地址
  imgBaseURL: 'http://ofv795nmp.bkt.clouddn.com/' // 图片服务器地址
}