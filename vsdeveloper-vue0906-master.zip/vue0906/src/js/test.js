// export default 导出的成员 可以使用任意的名称去接收
// 在一个模块中，只允许出现一次 export default
export default {
  info: { hobby: ['吃饭', '睡觉'] }
}

// 注意：使用 export 导出的成员，需要按需导入     import  { name }  from '模块标识符'
// 按需导出的成员，必须 使用 相同的成员名称来接收
// 在一个模块中，可以 export 按需导出多次
export var name = '尼古拉斯 赵四';
export var age = 22;