import Vue from 'vue'

// 6.0 创建全局时间过滤器
// 6.1 引入 moment.js 时间处理模块
import moment from 'moment'
Vue.filter('dateFormat', function (val, pattern = 'YYYY-MM-DD HH:mm:ss') {
  // moment.js

  // 下面这种方式，是获取当前时间，并根据指定字符串格式化
  // moment() 这是 获取 moment 类型的一个日期对象，直接调用的话，获取的是当前日期
  // moment().format(格式化字符串);

  // 根据给定的时间，和给定的格式化字符串，得到最终的时间字符串
  // moment('给定时间字符串').format(格式化字符串);
  return moment(val).format(pattern);
});