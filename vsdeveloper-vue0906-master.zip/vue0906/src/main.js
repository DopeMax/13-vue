// 1.1 先导入Vue模块
import Vue from 'vue'
// 导入 自己的 store 公共数据模块
import store from './js/store.js'


// 5.0 使用 vue-resource 请求数据
import VueResource from 'vue-resource'
// 将 VueResource 注册 到 Vue 上
Vue.use(VueResource);
// 导入全局配置对象
import config from './js/globalConfig.js'
// 设置 请求API接口时候，默认请求的数据API根路径
Vue.http.options.root = config.baseUrl;


// 6.0 注册 缩略图预览插件
import VuePreview from 'vue-preview'
Vue.use(VuePreview)


// 导入全局的过滤器模块
import './js/globalFilters.js'


// 1. 导入自己的路由模块
import router from './js/router.js'


// 3.1 导入安装的 Mint-UI 组件类库
// 如果是 将所有的组件 全部引入的话，在使用 CSS Component 的时候，不必在按需引入了，直接以标签形式引入组件即可
import Mint from 'mint-ui';
// 3.2 引入 样式
import 'mint-ui/lib/style.css'
// 3.3 将 Mint-UI 注册到 Vue 上
Vue.use(Mint);


// 使用 mui 组件
// 4.1 导入CSS样式
import './lib/mui/css/mui.min.css'
// 4.2 导入 MUI 扩展图标样式
import './lib/mui/css/icons-extra.css'


// 导入 App.vue 根组件
import App from './components/App.vue'

// 1.2 创建一个 Vue 实例
const vm = new Vue({
  el: '#app',
  render: c => c(App),
  router, // 2.4 将 路由对象，挂载到 VM 实例身上
  store // 将 公共的 数据仓储 挂载到 vm 上
});


// 导入模块
// import test123, { name as name1, age1 } from './js/test.js'
// console.log(test123);
// console.log(name1, age);